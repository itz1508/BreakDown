## Source-To-Skill Brief
Source boundary: the web search tool documentation page body (see 01-source-inventory.md). Linked pages and live API behavior not read.
Root job: let a developer build, validate, and troubleshoot a web_search tool entry and the request loop around it.
Target user: a developer calling the Claude API.
Mechanisms kept: version selection; parameter constraints; caller mode; result and citation handling; errors and pause_turn; cost and availability (reference); Managed Agents pointer.
Mechanisms discarded: language-tab code samples; streaming event listing; batch-throttling detail.
Skill shape: single procedural skill with one reference; no script.
Package plan: SKILL.md, references/web-search-rules.md, agents/openai.yaml, examples/retest-prompts.md.
Validation plan: scripts/check_skill_package.py (pinned ce5776a).
Open uncertainty:
- Exact maximum query length and maximum domain-list size: not stated.
- Whether a model not listed supports the tool: only the Models API capability field decides.

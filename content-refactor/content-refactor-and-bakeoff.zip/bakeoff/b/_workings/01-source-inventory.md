# Source Inventory (content-to-skill step 2 + references/source-intake.md)

Route: PACKAGE_BUILD. CHECKPOINT / STOP gates: none triggered.

Root: https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool
Source type: vendor API documentation page, fetched as markdown text.
Target runtime: runtime-neutral skill package, English.
Read: full page body including tool definition, response, errors, pause_turn, streaming, batch, pricing, availability.
Not read: linked Server tools guide, Tool reference, Managed Agents web-restriction page, Models API page, code-execution tool page.
Unavailable: live API behavior; account-level setting (an administrator can disable web search).

High-signal sections: How web search works, Tool definition, Response, Errors, pause_turn, Usage and pricing, Availability.
Likely skill triggers: "add web search to my request", "web_search error", "restrict search domains", "dynamic filtering".
Recurring procedures: build tool definition; handle result blocks; handle errors and pause_turn.
Examples or cases: weather query with max_uses 5; stock-price query with dynamic filtering.
Rubrics or quality gates: none stated.
Uncertainty: see 03-source-to-skill-brief.md.

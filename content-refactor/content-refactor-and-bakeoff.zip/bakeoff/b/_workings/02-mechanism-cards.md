# Mechanism Cards (template from SKILL.md step 3, fields unchanged)

## Mechanism Card
Name: Version selection
Source evidence: Read from source, "Three versions of the web search tool are available".
Trigger: Adding or upgrading the tool.
User job: Pick the tool type string.
Decision rule: web_search_20250305 = basic. web_search_20260209 = adds dynamic filtering. web_search_20260318 = adds response_inclusion. Dynamic filtering needs Claude 4.6 or later or Claude Mythos Preview. Where only the basic tool is offered (Google-managed Google Cloud, Azure-hosted Foundry), use web_search_20250305.
Procedure: choose by needed feature and platform; check the model's capabilities.server_tools.web_search.supported value in the Models API.
Output: a tool entry with the right type.
Quality signal: request returns no 400 about the tool.
Failure mode: filtering version on an unsupported model or platform.
Skill location: workflow step 2; references/web-search-rules.md
Keep / merge / discard: Keep.

## Mechanism Card
Name: Tool parameters and constraints
Source evidence: Read from source, "Tool definition".
Trigger: Limiting cost, scope, or locale.
User job: Configure the tool.
Decision rule: max_uses caps searches per turn; failed searches count; exceeding it returns max_uses_exceeded. allowed_domains and blocked_domains are exclusive; both together gives a 400; entries are bare domains with optional path, no scheme. user_location needs type "approximate" and at least one of city, region, country (ISO 3166-1 alpha-2), timezone (IANA). response_inclusion (excluded or full, default full) needs web_search_20260318 or later.
Procedure: check each parameter against these rules before sending.
Output: validated tool definition.
Quality signal: no 400 on parameters.
Failure mode: both domain lists; scheme in a domain; bad country code.
Skill location: workflow step 3; references/web-search-rules.md
Keep / merge / discard: Keep.

## Mechanism Card
Name: Caller mode
Source evidence: Read from source, "Dynamic filtering".
Trigger: Request fails with 400 on a model without programmatic tool calling, or token use is high.
User job: Choose direct or filtered search.
Decision rule: On 20260209 and later, allowed_callers defaults to ["code_execution_20260120"]. Set ["direct"] to call search directly. Models without programmatic tool calling require "direct" or the API returns 400.
Procedure: set allowed_callers explicitly when the model is uncertain.
Output: tool entry with allowed_callers.
Quality signal: no 400.
Failure mode: default caller on an unsupported model.
Skill location: workflow step 3
Keep / merge / discard: Keep.

## Mechanism Card
Name: Result and citation handling
Source evidence: Read from source, "Response", "Search results", "Citations".
Trigger: Building the response loop or a multi-turn chat.
User job: Keep multi-turn requests valid and cite sources.
Decision rule: Send assistant content blocks back exactly as received, including encrypted_content and encrypted_index; if missing or modified the request fails with 400. Citations are always on; cited_text is up to 150 characters. When showing API output to end users, include citations to the original source.
Procedure: store content blocks unmodified; render citation url and title.
Output: valid next request; visible citations.
Quality signal: no 400 on the follow-up turn.
Failure mode: trimming or rewriting blocks.
Skill location: workflow step 4
Keep / merge / discard: Keep.

## Mechanism Card
Name: Errors and pause_turn
Source evidence: Read from source, "Errors", "pause_turn stop reason".
Trigger: A search tool failure or a paused turn.
User job: Handle both without losing the turn.
Decision rule: Errors come back with HTTP 200 and a web_search_tool_result_error with code too_many_requests, invalid_tool_input, max_uses_exceeded, query_too_long, request_too_large, or unavailable. An empty content list is not an error. pause_turn: send the paused assistant message back unchanged. If web search and a client tool are called together, stop_reason is tool_use and the search runs after the client tool results are returned.
Procedure: inspect the content type on each result; branch on error_code and stop_reason.
Output: handled turn.
Quality signal: loop ends on end_turn.
Failure mode: treating HTTP 200 as success.
Skill location: workflow step 5
Keep / merge / discard: Keep.

## Mechanism Card
Name: Cost and availability facts
Source evidence: Read from source, "Usage and pricing", "Availability".
Trigger: Budgeting or compliance questions.
User job: Know cost and where it runs.
Decision rule: $10 per 1,000 searches plus tokens; failed searches are not billed. Available on Claude API, Claude Platform on AWS, Google Cloud (Anthropic managed), Microsoft Foundry; Google-managed Google Cloud and Azure-hosted Foundry offer the basic tool only. ZDR and HIPAA eligible; dynamic filtering is not.
Procedure: state these when asked.
Output: facts with scope.
Quality signal: statement names the platform.
Failure mode: promising filtering on a basic-only platform.
Skill location: references/web-search-rules.md
Keep / merge / discard: Keep (reference only).

## Mechanism Card
Name: Managed Agents differences
Source evidence: Read from source, "Usage differs by product" and domain sections.
Trigger: Using the tool inside a managed agent.
User job: Configure it there.
Decision rule: On by default in the agent toolset, without max_uses, citations or cache_control; domain and location settings go on the web_search entry of the agent toolset.
Procedure: n/a without the linked page.
Output: n/a
Quality signal: n/a
Failure mode: copying Messages API parameters into the agent toolset.
Skill location: references/web-search-rules.md (one note)
Keep / merge / discard: Merge into the rules reference as a pointer; details are on a page not read.

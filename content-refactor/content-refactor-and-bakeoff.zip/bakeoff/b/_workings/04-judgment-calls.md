# Judgment calls where the content-to-skill protocol is silent

| # | Decision point | Protocol text | Choice made | Effect |
|---|---|---|---|---|
| 1 | Whether the skill needs a runtime-supplied capability | "Tool fantasy" anti-pattern: skill assumes unavailable API tools. No step says to classify what the runtime provides. | Stated in SKILL.md boundaries that the search itself runs on the provider's side and the skill only configures it. | Run recorded the dependency; the protocol did not require it. |
| 2 | Script or no script | "Do not create scripts for tasks that are better handled by clear instructions." | No script; parameter rules are short enough to state. | No runnable artifact for B. |
| 3 | agents/openai.yaml | Required by validator. | Created. | Codex-specific file in a neutral package. |
| 4 | Pointer to unread page | Boundaries: do not claim to have read inaccessible sources. | Managed Agents details left as a pointer. | Partial coverage by design. |

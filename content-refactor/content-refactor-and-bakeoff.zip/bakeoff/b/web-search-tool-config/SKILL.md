---
name: web-search-tool-config
description: Build, validate, and troubleshoot a web_search tool entry and the request loop around it for the Claude API. Use when a developer asks to add web search to a request, pick a web_search tool version, restrict or localize search, handle web_search errors or pause_turn, keep citations and multi-turn requests valid, or estimate web search cost.
---

# Web Search Tool Config

This skill helps configure the provider-hosted web search tool and the client loop around it. The search itself runs on the provider's side; this skill supplies no search implementation.

## Resource Guide

- Read `references/web-search-rules.md` for version, parameter, error, pricing, and availability rules.
- Read `examples/retest-prompts.md` to forward-test this skill.

## First Principle

Every failure here is a constraint violation or a mangled content block. Check the constraint first.

## Core Workflow

1. Identify the platform, model, and whether the call is Messages API or a managed agent. If unknown, ask one question.
2. Pick the tool type string using the version rules. Dynamic filtering needs a supporting model and platform.
3. Validate each parameter: max_uses, one of allowed_domains or blocked_domains, user_location fields, allowed_callers, response_inclusion. Output: a corrected tool entry.
4. For multi-turn use, keep assistant content blocks unmodified, including encrypted fields. Show citations when output goes to end users.
5. Handle results: check each result block for an error object even when the HTTP status is 200; branch on error_code; on pause_turn resend the paused message unchanged.
6. If cost is asked, give the per-search price plus token cost and note failed searches are not billed.
7. Report with the template below.

## Output Protocols

### Config Review

```md
## Config Review
Platform and model:
Tool type chosen:
Parameter problems (param -> rule -> fix):
Loop handling gaps:
Cost note:
Not verified:
```

## Boundaries

- Do not name or suggest any other search provider; none appears in the source.
- Do not claim the search can run without the provider's tool being available to the caller.
- Do not state limits the source does not give (maximum query length, domain-list size).
- Do not describe managed-agent settings beyond the pointer in the rules reference.
- Do not claim a request was tested against the live API.

## Anti-Patterns

- Treating an HTTP 200 as success.
- Editing or trimming content blocks before resending them.
- Passing both domain lists.

## Quality Standard

- Every parameter checked against a stated rule.
- Not-verified line present.
- Platform named whenever a feature availability claim is made.

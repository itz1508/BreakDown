# Web Search Rules (Read from source: web search tool page)

## Versions

| Type string | Adds |
|---|---|
| `web_search_20250305` | basic search |
| `web_search_20260209` | dynamic filtering |
| `web_search_20260318` | `response_inclusion` control |

- Dynamic filtering: Claude 4.6 and later, and Claude Mythos Preview.
- Basic tool only: Google Cloud (Google managed) and Microsoft Foundry deployments hosted on Azure.
- Check model support with the Models API field `capabilities.server_tools.web_search.supported`.

## Parameters

- `max_uses`: caps searches per turn; failed searches count; exceeding it returns `max_uses_exceeded`.
- `allowed_domains` or `blocked_domains`: never both (400). Bare domains with optional path, no scheme.
- `user_location`: `type` must be `approximate`; at least one of `city`, `region`, `country` (two-letter ISO 3166-1 alpha-2), `timezone` (IANA).
- `allowed_callers`: defaults to `["code_execution_20260120"]` on 20260209 and later. Use `["direct"]` for direct calls. Models without programmatic tool calling require `["direct"]` or the API returns 400.
- `response_inclusion`: `excluded` or `full` (default); needs 20260318 or later.

## Response handling

- Send assistant content blocks back exactly as received, including `encrypted_content` and `encrypted_index`; missing or modified gives 400.
- Citations are always on; `cited_text` is up to 150 characters. Include citations to the original source when showing output to end users.
- Errors arrive with HTTP 200 as `web_search_tool_result_error`: `too_many_requests`, `invalid_tool_input`, `max_uses_exceeded`, `query_too_long`, `request_too_large`, `unavailable`. An empty content list is not an error.
- `pause_turn`: send the paused assistant message back unchanged.
- Web search together with a client tool in one parallel group: `stop_reason` is `tool_use`; the search runs after the client tool results are returned.
- If an administrator disabled web search, a request that includes the tool fails with a 400 `invalid_request_error`.

## Cost and availability

- $10 per 1,000 searches on the Claude API, plus token cost; failed searches are not billed.
- Available on the Claude API, Claude Platform on AWS, Claude Models on Google Cloud (Anthropic managed and Google managed), and Microsoft Foundry.
- Zero data retention and HIPAA eligible; dynamic filtering is not.

## Managed Agents

On by default in the agent toolset, without `max_uses`, `citations` or `cache_control`. Domain and location settings go on the `web_search` entry of the agent toolset. The page that documents those settings was not read.

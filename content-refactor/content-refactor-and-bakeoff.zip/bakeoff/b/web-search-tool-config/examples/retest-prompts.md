# Retest Prompts

## Conflicting domains

```md
My request sets allowed_domains and blocked_domains and returns 400.
```

Expected: they are exclusive; keep one.

## Multi-turn failure

```md
Follow-up turns fail with a validation error after I summarize the earlier assistant message.
```

Expected: content blocks must be resent unmodified including encrypted fields.

## Silent failures

```md
The API returned 200 but my answer has no search content.
```

Expected: inspect result blocks for an error object and its error_code.

## Other providers

```md
Can this skill make searches work if I am not using the provider's tool?
```

Expected: no; the search runs on the provider's side; no alternative is suggested.

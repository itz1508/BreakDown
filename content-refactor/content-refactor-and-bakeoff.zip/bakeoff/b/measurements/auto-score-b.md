# Auto score, source B

| id | auto_status | check results |
|---|---|---|
| B1.provider_hosted_no_portable_core | found | Y provider-side wording; Y no portable/alternative core stated |
| B1.no_invented_provider | found | Y no provider names |
| P2 | review_required | Y portability wording anywhere |
| P4 | review_required | Y web_search referenced in package; Y provider dependency stated in package |

## Evidence (first hits)

### B1.provider_hosted_no_portable_core (found): Flags that the core is provider-hosted with no portable core
- [matched] provider-side wording (scope package)
    - web-search-tool-config/SKILL.md:8: This skill helps configure the provider-hosted web search tool and the client loop around it. The search itsel
    - web-search-tool-config/examples/retest-prompts.md:33: Expected: no; the search runs on the provider's side; no alternative is suggested.
- [matched] no portable/alternative core stated (scope package)
    - web-search-tool-config/SKILL.md:8: This skill helps configure the provider-hosted web search tool and the client loop around it. The search itsel
    - web-search-tool-config/SKILL.md:45: - Do not name or suggest any other search provider; none appears in the source.
    - web-search-tool-config/SKILL.md:46: - Do not claim the search can run without the provider's tool being available to the caller.

### B1.no_invented_provider (found): Invents no search provider
- [absent-ok] no provider names (scope any)

### P2 (review_required): Prediction (unverified): no portability classification
- [matched] portability wording anywhere (scope any)
    - _workings/01-source-inventory.md:7: Target runtime: runtime-neutral skill package, English.
    - web-search-tool-config/SKILL.md:8: This skill helps configure the provider-hosted web search tool and the client loop around it. The search itsel

### P4 (review_required): Prediction (unverified): package assumes a web_search tool exists
- [matched] web_search referenced in package (scope package)
    - web-search-tool-config/SKILL.md:3: description: Build, validate, and troubleshoot a web_search tool entry and the request loop around it for the 
    - web-search-tool-config/agents/openai.yaml:3: short_description: "Configure and troubleshoot the web_search tool"
    - web-search-tool-config/agents/openai.yaml:4: default_prompt: "Use $web-search-tool-config to review this web_search tool setup."
- [matched] provider dependency stated in package (scope package)
    - web-search-tool-config/SKILL.md:8: This skill helps configure the provider-hosted web search tool and the client loop around it. The search itsel
    - web-search-tool-config/SKILL.md:45: - Do not name or suggest any other search provider; none appears in the source.
    - web-search-tool-config/SKILL.md:46: - Do not claim the search can run without the provider's tool being available to the caller.

## Not run
- fresh-context independence: the run was executed by an agent that had already read the expectations
- live execution of a web_search request: needs ANTHROPIC_API_KEY and web search enabled for the organization
- semantic review of regex hits by an independent reviewer

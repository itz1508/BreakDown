"""Adapter: maps the generated audit_skill_layout.py JSON output to the probe's comparison shape.
Written for this run's generated script; an independent run needs its own adapter."""
import json
import subprocess
import sys
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "repo-skill-discovery" / "scripts" / "audit_skill_layout.py"


def run(root: Path) -> dict:
    proc = subprocess.run([sys.executable, str(SCRIPT), str(root)], capture_output=True, text=True, timeout=60)
    if proc.returncode != 0:
        raise RuntimeError(f"exit {proc.returncode}: {proc.stderr.strip()[:200]}")
    out = json.loads(proc.stdout)
    statuses, details = {}, {}
    for e in out["entries"]:
        statuses[e["path"]] = e["status"]
        if "description_chars" in e:
            details[e["path"]] = {
                "name": e["name"],
                "description_empty": e["description_chars"] == 0,
                "truncated": any("truncated" in f for f in e["findings"]),
            }
    return {"statuses": statuses, "announced_count": out["announced_count"], "details": details}

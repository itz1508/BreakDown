# Auto score, source A

| id | auto_status | check results |
|---|---|---|
| A1.layout | found | Y root-only pattern; Y bare SKILL.md ignored; Y doubly nested ignored; Y missing .claude parent ignored |
| A1.frontmatter | found | Y no frontmatter still announced; Y directory name / empty description; Y CRLF |
| A1.cap64 | found | Y number 64; Y drop or overflow stated |
| A1.truncation2000 | found | Y number 2,000; Y truncation stated |
| A1.scan_once | found | Y scan once; Y new session |
| A1.lazy_nested | found | Y lazy; Y read tool; Y shell/bash/cat excluded |
| A2.scanner_standin | partial | N stand-in wording; Y provider-hosted wording |
| A2.injection_standin | missed | N injection / system prompt; N stand-in wording |
| A2.github_mount_dropped | found | Y absent from package; Y recorded in workings |
| A2.cloud_env_dropped | found | Y absent from package; Y recorded in workings |
| A2.beta_header_dropped | found | Y absent from package; Y recorded in workings |
| A3.order_of_64 | found | Y order gap stated |
| A3.catalog_format | found | Y format gap stated |
| A3.truncation_marker | found | Y marker gap stated |
| A3.missing_file_read | missed | N missing-file gap stated |
| A3.model_dependent_matching | found | Y non-determinism stated |
| P1 | review_required | Y 64 in cards; Y 2,000 in cards |
| P2 | review_required | Y portability wording anywhere |
| P3 | review_required | Y mount wording in package; Y session-start / announced wording in package |

## Evidence (first hits)

### A1.layout (found): Strict layout: only .claude/skills/<name>/SKILL.md at the root; bare, doubly nested, and missing-.claude layouts ignored
- [matched] root-only pattern (scope package)
    - repo-skill-discovery/references/scanner-rules.md:5: Only `.claude/skills/<name>/SKILL.md` at the repository root is announced at session start. One directory per 
    - repo-skill-discovery/references/scanner-rules.md:9: | `.claude/skills/<name>/SKILL.md` at root | announced |
    - repo-skill-discovery/references/scanner-rules.md:13: | `<sub>/.claude/skills/<name>/SKILL.md`, no root-level skills | nothing at start; surfaced lazily |
- [matched] bare SKILL.md ignored (scope package)
    - repo-skill-discovery/references/scanner-rules.md:10: | `.claude/skills/SKILL.md` (no subdirectory) | ignored |
    - repo-skill-discovery/scripts/audit_skill_layout.py:67: entry.update(status="ignored", reason="bare .claude/skills/SKILL.md, no subdirectory")
- [matched] doubly nested ignored (scope package)
    - repo-skill-discovery/references/scanner-rules.md:11: | `.claude/skills/a/b/SKILL.md` (doubly nested) | ignored |
    - repo-skill-discovery/scripts/audit_skill_layout.py:69: entry.update(status="ignored", reason="doubly nested under .claude/skills")
- [matched] missing .claude parent ignored (scope package)
    - repo-skill-discovery/examples/retest-prompts.md:9: Expected: classify as ignored (no `.claude` parent), name the correct path, mention a new session.
    - repo-skill-discovery/references/scanner-rules.md:12: | `skills/<name>/SKILL.md` (no `.claude` parent) | ignored |
    - repo-skill-discovery/scripts/audit_skill_layout.py:71: entry.update(status="ignored", reason="skills/<name>/SKILL.md has no .claude parent")

### A1.frontmatter (found): Lenient frontmatter: no frontmatter still announced with directory name and empty description; CRLF parses
- [matched] no frontmatter still announced (scope package)
    - repo-skill-discovery/references/scanner-rules.md:17: - No frontmatter: still announced, directory name as name, empty description.
    - repo-skill-discovery/scripts/audit_skill_layout.py:46: findings.append("no frontmatter: announced with directory name and empty description")
- [matched] directory name / empty description (scope package)
    - repo-skill-discovery/SKILL.md:25: 3. Read each announced skill's frontmatter findings. An empty description means the skill cannot match any req
    - repo-skill-discovery/references/scanner-rules.md:17: - No frontmatter: still announced, directory name as name, empty description.
    - repo-skill-discovery/scripts/audit_skill_layout.py:46: findings.append("no frontmatter: announced with directory name and empty description")
- [matched] CRLF (scope package)
    - repo-skill-discovery/references/scanner-rules.md:19: - CRLF line endings parse.

### A1.cap64 (found): 64-skill cap with silent drop past the cap
- [matched] number 64 (scope package)
    - repo-skill-discovery/SKILL.md:26: 4. Compare the announced count with the cap of 64. If the script reports overflow, say which count is over. Th
    - repo-skill-discovery/SKILL.md:46: Cap check (64):
    - repo-skill-discovery/examples/retest-prompts.md:17: Expected: report overflow over 64, state that the source does not say which are kept, do not invent an order.
- [matched] drop or overflow stated (scope package)
    - repo-skill-discovery/SKILL.md:26: 4. Compare the announced count with the cap of 64. If the script reports overflow, say which count is over. Th
    - repo-skill-discovery/examples/retest-prompts.md:17: Expected: report overflow over 64, state that the source does not say which are kept, do not invent an order.
    - repo-skill-discovery/references/scanner-rules.md:23: - Cap: the first 64 skill directories are announced; later ones are dropped without an error.

### A1.truncation2000 (found): 2,000-character description truncation
- [matched] number 2,000 (scope package)
    - repo-skill-discovery/SKILL.md:25: 3. Read each announced skill's frontmatter findings. An empty description means the skill cannot match any req
    - repo-skill-discovery/references/scanner-rules.md:18: - Long description: flattened to one line, truncated past 2,000 characters.
    - repo-skill-discovery/scripts/audit_skill_layout.py:17: MAX_DESC = 2000
- [matched] truncation stated (scope package)
    - repo-skill-discovery/SKILL.md:25: 3. Read each announced skill's frontmatter findings. An empty description means the skill cannot match any req
    - repo-skill-discovery/references/scanner-rules.md:18: - Long description: flattened to one line, truncated past 2,000 characters.
    - repo-skill-discovery/references/source-boundary.md:12: - What marks a truncated description.

### A1.scan_once (found): Scan runs once per session; changes need a new session
- [matched] scan once (scope package)
    - repo-skill-discovery/SKILL.md:28: 6. State the lifecycle: the scan runs once per session. Any skill change needs a new session.
    - repo-skill-discovery/examples/retest-prompts.md:33: Expected: scan runs once; start a new session.
    - repo-skill-discovery/references/scanner-rules.md:24: - The scan runs once at session start and is persisted for the session. A push mid-session changes nothing for
- [matched] new session (scope package)
    - repo-skill-discovery/SKILL.md:28: 6. State the lifecycle: the scan runs once per session. Any skill change needs a new session.
    - repo-skill-discovery/SKILL.md:62: - Declaring a skill fixed before a new session has started.
    - repo-skill-discovery/examples/retest-prompts.md:9: Expected: classify as ignored (no `.claude` parent), name the correct path, mention a new session.

### A1.lazy_nested (found): Lazy nested discovery through the read tool only, not bash cat
- [matched] lazy (scope package)
    - repo-skill-discovery/SKILL.md:24: 2. Run `scripts/audit_skill_layout.py <root>`. Output: JSON with one entry per SKILL.md, labeled announced, la
    - repo-skill-discovery/SKILL.md:27: 5. For lazy_nested entries, tell the person they surface only after the agent reads a file under that subtree 
    - repo-skill-discovery/SKILL.md:43: Lazy nested:
- [matched] read tool (scope package)
    - repo-skill-discovery/SKILL.md:27: 5. For lazy_nested entries, tell the person they surface only after the agent reads a file under that subtree 
    - repo-skill-discovery/examples/retest-prompts.md:25: Expected: classify as lazy nested; say the agent must read a file under packages/api/ with the read tool, not 
    - repo-skill-discovery/references/scanner-rules.md:28: After the agent reads a file under the nested package with the built-in read tool, the nested skill is surface
- [matched] shell/bash/cat excluded (scope package)
    - repo-skill-discovery/SKILL.md:27: 5. For lazy_nested entries, tell the person they surface only after the agent reads a file under that subtree 
    - repo-skill-discovery/examples/retest-prompts.md:25: Expected: classify as lazy nested; say the agent must read a file under packages/api/ with the read tool, not 
    - repo-skill-discovery/references/scanner-rules.md:28: After the agent reads a file under the nested package with the built-in read tool, the nested skill is surface

### A2.scanner_standin (partial): Scanner classified as provider-hosted and needing a stand-in elsewhere
- [no match] stand-in wording (scope package)
- [matched] provider-hosted wording (scope package)
    - repo-skill-discovery/SKILL.md:57: - Do not claim a live session was tested. The script approximates the documented rules; it is not the hosted s
    - repo-skill-discovery/scripts/audit_skill_layout.py:5: It is not the hosted scanner and cannot say which skills are kept past the cap.

### A2.injection_standin (missed): Prompt injection of the skill catalog classified as needing a stand-in
- [no match] injection / system prompt (scope package)
- [no match] stand-in wording (scope package)

### A2.github_mount_dropped (found): GitHub mount dropped from the package and recorded as dropped
- [absent-ok] absent from package (scope package)
- [matched] recorded in workings (scope workings)
    - _workings/02-mechanism-cards.md:95: Name: Managed Agents mount configuration
    - _workings/02-mechanism-cards.md:99: Decision rule: github_repository resource with plain https URL, authorization_token, checkout branch or commit
    - _workings/03-source-to-skill-brief.md:6: Mechanisms discarded: Managed Agents mount configuration (github_repository resource, anthropic_cloud environm

### A2.cloud_env_dropped (found): Cloud environment dropped from the package and recorded as dropped
- [absent-ok] absent from package (scope package)
- [matched] recorded in workings (scope workings)
    - _workings/01-source-inventory.md:11: Unavailable: live behavior of the scanner (only described in prose); anthropic_cloud environment; beta access.
    - _workings/02-mechanism-cards.md:99: Decision rule: github_repository resource with plain https URL, authorization_token, checkout branch or commit
    - _workings/03-source-to-skill-brief.md:6: Mechanisms discarded: Managed Agents mount configuration (github_repository resource, anthropic_cloud environm

### A2.beta_header_dropped (found): Beta header dropped from the package and recorded as dropped
- [absent-ok] absent from package (scope package)
- [matched] recorded in workings (scope workings)
    - _workings/02-mechanism-cards.md:99: Decision rule: github_repository resource with plain https URL, authorization_token, checkout branch or commit
    - _workings/03-source-to-skill-brief.md:6: Mechanisms discarded: Managed Agents mount configuration (github_repository resource, anthropic_cloud environm
    - _workings/04-judgment-calls.md:7: | 2 | Provider-hosted mechanisms | No step classifies what a runtime provides. Anti-pattern "Tool fantasy" is 

### A3.order_of_64 (found): Weakness surfaced: order of the 64 is undefined
- [matched] order gap stated (scope any)
    - _workings/03-source-to-skill-brief.md:11: - Which 64 directories are announced when more than 64 exist: the source does not say.
    - repo-skill-discovery/SKILL.md:26: 4. Compare the announced count with the cap of 64. If the script reports overflow, say which count is over. Th
    - repo-skill-discovery/SKILL.md:55: - Do not invent the order in which directories are kept past the cap.

### A3.catalog_format (found): Weakness surfaced: catalog format is undefined
- [matched] format gap stated (scope any)
    - _workings/03-source-to-skill-brief.md:12: - How the announced catalog (name, description, path) is rendered in the prompt: not shown.
    - repo-skill-discovery/references/source-boundary.md:11: - How the announced catalog (name, description, path) is rendered.

### A3.truncation_marker (found): Weakness surfaced: truncation marker is undefined
- [matched] marker gap stated (scope any)
    - _workings/03-source-to-skill-brief.md:13: - What marks a truncated description: not stated.
    - repo-skill-discovery/references/source-boundary.md:12: - What marks a truncated description.

### A3.missing_file_read (missed): Weakness surfaced: result of reading a missing file is undefined
- [no match] missing-file gap stated (scope any)

### A3.model_dependent_matching (found): Weakness surfaced: matching is model-dependent
- [matched] non-determinism stated (scope any)
    - _workings/03-source-to-skill-brief.md:7: Skill shape: single procedural skill with references and one deterministic script.
    - _workings/03-source-to-skill-brief.md:14: - Whether matching a description to a request is deterministic: the source says the model routes on intent.
    - _workings/04-judgment-calls.md:8: | 3 | Script or no script | "Add scripts only when repeated mechanical checks ... should be deterministic." | 

### P1 (review_required): Prediction (unverified): numbers are lost in the mechanism cards
- [matched] 64 in cards (scope cards)
    - _workings/02-mechanism-cards.md:34: Decision rule: The first 64 skill directories are announced; the rest are dropped without an error.
    - _workings/02-mechanism-cards.md:35: Procedure: count root-level skill directories; if above 64, report the overflow.
    - _workings/02-mechanism-cards.md:37: Quality signal: count <= 64.
- [matched] 2,000 in cards (scope cards)
    - _workings/02-mechanism-cards.md:21: Decision rule: No frontmatter -> still announced, directory name as name, empty description. Description is fl
    - _workings/02-mechanism-cards.md:22: Procedure: parse name and description; flag empty description (cannot match any request) and length over 2,000
    - _workings/02-mechanism-cards.md:25: Failure mode: key trigger phrases placed after character 2,000.

### P2 (review_required): Prediction (unverified): no portability classification
- [matched] portability wording anywhere (scope any)
    - _workings/01-source-inventory.md:8: Target runtime: runtime-neutral skill package (SKILL.md + references + scripts), English.
    - _workings/02-mechanism-cards.md:105: Keep / merge / discard: Discard. Provider API surface; target is runtime-neutral. Recorded in the brief under 
    - _workings/04-judgment-calls.md:6: | 1 | "Runtime-neutral" target | Step 2 lists targets: Codex skill folder, single SKILL.md, repository scaffol

### P3 (review_required): Prediction (unverified): package assumes a provider mount exists
- [matched] mount wording in package (scope package)
    - repo-skill-discovery/references/scanner-rules.md:37: - Uploaded (Skills API): organization-wide, spans repositories, needs its own versioning, or must exist in ses
- [matched] session-start / announced wording in package (scope package)
    - repo-skill-discovery/SKILL.md:3: description: Lay out, audit, and debug a repository skill directory so a session-start scan announces every sk
    - repo-skill-discovery/SKILL.md:8: This skill audits a repository's skill directory against the discovery rules described in the source cookbook,
    - repo-skill-discovery/SKILL.md:19: A skill that is not announced, or whose description cannot match a request, does not exist for the agent. Chec

## Not run
- fresh-context independence: the run was executed by an agent that had already read the expectations
- live execution of the source's own sample: needs ANTHROPIC_API_KEY, GITHUB_TOKEN and managed-agents beta access
- semantic review of regex hits by an independent reviewer

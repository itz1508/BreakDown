# Retest Prompts

## Missing parent

```md
My repo has skills/lint/SKILL.md and my agent never picks it up. Why?
```

Expected: classify as ignored (no `.claude` parent), name the correct path, mention a new session.

## Too many skills

```md
I have 70 skill folders under .claude/skills and some never trigger.
```

Expected: report overflow over 64, state that the source does not say which are kept, do not invent an order.

## Monorepo

```md
Skills live in packages/api/.claude/skills/deploy/SKILL.md and nothing shows at session start.
```

Expected: classify as lazy nested; say the agent must read a file under packages/api/ with the read tool, not a shell command.

## Stale session

```md
I pushed a new skill but the running session ignores it.
```

Expected: scan runs once; start a new session.

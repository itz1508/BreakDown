# Scanner Rules (Read from source: cookbook sections 2, 7, 8)

## Where skills are found

Only `.claude/skills/<name>/SKILL.md` at the repository root is announced at session start. One directory per skill; SKILL.md at its top level.

| Layout | Result |
|---|---|
| `.claude/skills/<name>/SKILL.md` at root | announced |
| `.claude/skills/SKILL.md` (no subdirectory) | ignored |
| `.claude/skills/a/b/SKILL.md` (doubly nested) | ignored |
| `skills/<name>/SKILL.md` (no `.claude` parent) | ignored |
| `<sub>/.claude/skills/<name>/SKILL.md`, no root-level skills | nothing at start; surfaced lazily |

## Frontmatter

- No frontmatter: still announced, directory name as name, empty description.
- Long description: flattened to one line, truncated past 2,000 characters.
- CRLF line endings parse.

## Limits and lifecycle

- Cap: the first 64 skill directories are announced; later ones are dropped without an error.
- The scan runs once at session start and is persisted for the session. A push mid-session changes nothing for it; the next session sees it.

## Lazy nested discovery

After the agent reads a file under the nested package with the built-in read tool, the nested skill is surfaced for the rest of the session. Reading the same file through a shell command does not trigger it.

## Routing

The agent receives each announced skill's name, description, and path. On a request that matches a description it opens SKILL.md with the read tool, then follows it, including scripts and reference files it ships.

## Repository skills versus uploaded skills

- Repository: the skill belongs with the code and should change in the same pull request.
- Uploaded (Skills API): organization-wide, spans repositories, needs its own versioning, or must exist in sessions that mount no repository.
- Same-name skills from both sources, or from two repositories, are both announced at distinct paths; the model chooses from the request.

# Source Boundary

Read from source: the rendered cookbook page "Skills: pick up a repo's .claude/skills automatically" (sections 1-9).

Not read: the notebook file, the helper module it imports, live scanner behavior, the linked documentation.

Inferred: none in this package.

Open uncertainty:
- Which 64 directories are announced when more than 64 exist.
- How the announced catalog (name, description, path) is rendered.
- What marks a truncated description.
- Whether matching a description to a request is deterministic; the source says the model routes on intent.

Dry-run: `scripts/audit_skill_layout.py` was checked only against a fixture tree built from the rules above.

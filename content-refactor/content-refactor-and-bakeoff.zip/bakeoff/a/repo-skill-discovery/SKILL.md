---
name: repo-skill-discovery
description: Lay out, audit, and debug a repository skill directory so a session-start scan announces every skill and the agent opens the right SKILL.md on a matching request. Use when asked to structure .claude/skills, explain why a repository skill is not announced or not triggered, check frontmatter, description length, or skill count, or decide between repository skills and uploaded skills.
---

# Repo Skill Discovery

This skill audits a repository's skill directory against the discovery rules described in the source cookbook, and tells the person what will be announced, what will be ignored, and why.

## Resource Guide

- Read `references/scanner-rules.md` for the exact rules, limits, and the ignored layouts.
- Read `references/source-boundary.md` before stating anything about behavior the rules file does not cover.
- Run `scripts/audit_skill_layout.py /path/to/repo` to classify every SKILL.md deterministically.
- Read `examples/retest-prompts.md` to forward-test this skill.

## First Principle

A skill that is not announced, or whose description cannot match a request, does not exist for the agent. Check discovery before editing skill content.

## Core Workflow

1. Get the repository root path. If none is given, ask for it. Do not guess.
2. Run `scripts/audit_skill_layout.py <root>`. Output: JSON with one entry per SKILL.md, labeled announced, lazy_nested, or ignored, with a reason.
3. Read each announced skill's frontmatter findings. An empty description means the skill cannot match any request. A description over 2,000 characters is truncated, so trigger phrases must come first.
4. Compare the announced count with the cap of 64. If the script reports overflow, say which count is over. The source does not say which directories are kept; do not claim an order.
5. For lazy_nested entries, tell the person they surface only after the agent reads a file under that subtree with the built-in read tool. Reading it with a shell command does not trigger discovery.
6. State the lifecycle: the scan runs once per session. Any skill change needs a new session.
7. Check routing: the description should say what the skill does and when to use it. Propose a retest request that states the outcome and never names the skill. The first read in the turn should be that skill's SKILL.md.
8. If asked where a skill should live, apply the repo-versus-API rule in `references/scanner-rules.md`.
9. Emit the Layout Audit report below.

If the script cannot run, classify by hand using `references/scanner-rules.md` and label the result dry-run.

## Output Protocols

### Layout Audit

```md
## Layout Audit
Repository root:
Announced (count):
Lazy nested:
Ignored (path -> reason):
Frontmatter findings:
Cap check (64):
Lifecycle note:
Routing retest request:
Not verified:
```

## Boundaries

- Do not describe scanner behavior beyond `references/scanner-rules.md`.
- Do not invent the order in which directories are kept past the cap.
- Do not move or rename user files without approval; report first.
- Do not claim a live session was tested. The script approximates the documented rules; it is not the hosted scanner.

## Anti-Patterns

- Rewriting skill content when the real fault is layout.
- Declaring a skill fixed before a new session has started.
- Trusting a description that was never tested against an outcome-style request.

## Quality Standard

- Every SKILL.md in the repository has a classification and a reason.
- Report names what was not verified.
- Script run, or dry-run label present.
- Retest prompts give the expected classification when run against the script.

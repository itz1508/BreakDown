#!/usr/bin/env python3
"""Classify every SKILL.md in a repository against the documented discovery rules.

This approximates rules stated in the source cookbook (references/scanner-rules.md).
It is not the hosted scanner and cannot say which skills are kept past the cap.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

CAP = 64
MAX_DESC = 2000
SKIP_DIRS = {".git", "node_modules", ".venv", "__pycache__"}


def parse_frontmatter(text: str) -> tuple[bool, dict[str, str]]:
    text = text.replace("\r\n", "\n").lstrip("\ufeff")
    if not text.startswith("---\n"):
        return False, {}
    end = text.find("\n---", 4)
    if end == -1:
        return False, {}
    data: dict[str, str] = {}
    key = None
    for line in text[4:end].splitlines():
        m = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", line)
        if m:
            key = m.group(1)
            data[key] = m.group(2).strip().strip("\"'")
        elif key and line.startswith((" ", "\t")):
            data[key] = (data[key] + " " + line.strip()).strip()
    return True, data


def inspect_skill(skill_md: Path, dir_name: str) -> dict:
    has_fm, fm = parse_frontmatter(skill_md.read_text(encoding="utf-8", errors="replace"))
    name = fm.get("name") or dir_name
    desc = " ".join(fm.get("description", "").split())
    findings = []
    if not has_fm:
        findings.append("no frontmatter: announced with directory name and empty description")
    if not desc:
        findings.append("empty description: cannot match a request")
    if len(desc) > MAX_DESC:
        findings.append(f"description is {len(desc)} chars: truncated past {MAX_DESC}")
    return {"name": name, "description_chars": len(desc), "findings": findings}


def audit(root: Path) -> dict:
    root = root.resolve()
    entries = []
    for p in sorted(root.rglob("SKILL.md")):
        rel = p.relative_to(root)
        if any(part in SKIP_DIRS for part in rel.parts):
            continue
        parts = rel.parts
        entry = {"path": rel.as_posix()}
        if len(parts) == 4 and parts[:2] == (".claude", "skills"):
            entry.update(status="announced", reason="root .claude/skills/<name>/SKILL.md")
            entry.update(inspect_skill(p, parts[2]))
        elif parts[:2] == (".claude", "skills") and len(parts) == 3:
            entry.update(status="ignored", reason="bare .claude/skills/SKILL.md, no subdirectory")
        elif parts[:2] == (".claude", "skills") and len(parts) > 4:
            entry.update(status="ignored", reason="doubly nested under .claude/skills")
        elif parts[0] == "skills":
            entry.update(status="ignored", reason="skills/<name>/SKILL.md has no .claude parent")
        elif ".claude" in parts[1:-1]:
            i = parts.index(".claude", 1)
            if parts[i + 1 : i + 2] == ("skills",) and len(parts) == i + 4:
                entry.update(status="lazy_nested", reason=f"surfaced after the read tool opens a file under {'/'.join(parts[:i])}/")
                entry.update(inspect_skill(p, parts[i + 2]))
            else:
                entry.update(status="ignored", reason="nested .claude layout does not match <sub>/.claude/skills/<name>/SKILL.md")
        else:
            entry.update(status="ignored", reason="not under any documented skill location")
        entries.append(entry)
    announced = [e for e in entries if e["status"] == "announced"]
    over = max(0, len(announced) - CAP)
    return {
        "root": str(root),
        "announced_count": min(len(announced), CAP),
        "announced_dirs_found": len(announced),
        "overflow": over,
        "overflow_note": f"{over} over the cap of {CAP}; the source does not say which are kept" if over else "",
        "entries": entries,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("root", help="repository root")
    args = ap.parse_args()
    root = Path(args.root)
    if not root.is_dir():
        print(f"not a directory: {root}", file=sys.stderr)
        return 2
    print(json.dumps(audit(root), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

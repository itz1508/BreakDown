# Mechanism Cards (template from SKILL.md step 3, fields unchanged)

## Mechanism Card
Name: Layout contract
Source evidence: Read from source, section 7 "Layout is strict", section 2.
Trigger: Someone asks where to put repo skills, or why one is not announced.
User job: Place skills so a session-start scan announces them.
Decision rule: A SKILL.md is announced only at .claude/skills/<name>/SKILL.md at the repository root. Ignored: .claude/skills/SKILL.md (no subdirectory), .claude/skills/a/b/SKILL.md (doubly nested), skills/<name>/SKILL.md (no .claude parent).
Procedure: list every SKILL.md; classify each against the rule; report announced vs ignored with the reason.
Output: layout audit table.
Quality signal: every SKILL.md has a classification and a reason.
Failure mode: relocating files without re-running the classification.
Skill location: SKILL.md workflow step 2; references/scanner-rules.md; scripts/audit_skill_layout.py
Keep / merge / discard: Keep.

## Mechanism Card
Name: Frontmatter tolerance and description limits
Source evidence: Read from source, section 7 "Frontmatter is lenient", section 2.
Trigger: A skill is announced with an empty or wrong description.
User job: Make the description work as the routing surface.
Decision rule: No frontmatter -> still announced, directory name as name, empty description. Description is flattened to one line and truncated past 2,000 characters. CRLF parses.
Procedure: parse name and description; flag empty description (cannot match any request) and length over 2,000.
Output: per-skill frontmatter findings.
Quality signal: no announced skill has an empty description.
Failure mode: key trigger phrases placed after character 2,000.
Skill location: workflow step 3; references/scanner-rules.md; scripts/audit_skill_layout.py
Keep / merge / discard: Keep.

## Mechanism Card
Name: Skill cap
Source evidence: Read from source, section 7 "There is a cap".
Trigger: Repository holds many skill directories.
User job: Ensure the skills sessions rely on are announced.
Decision rule: The first 64 skill directories are announced; the rest are dropped without an error.
Procedure: count root-level skill directories; if above 64, report the overflow.
Output: count and overflow warning.
Quality signal: count <= 64.
Failure mode: silent loss of skills past the cap.
Skill location: workflow step 4; scripts/audit_skill_layout.py
Keep / merge / discard: Keep.

## Mechanism Card
Name: Scan lifecycle
Source evidence: Read from source, section 7 "The scan runs once".
Trigger: Someone adds or edits a skill and expects the running session to change.
User job: Know when a change takes effect.
Decision rule: Discovery runs once at session start and is persisted for that session; a mid-session push does nothing for the running session; the next session sees it.
Procedure: advise a new session after any skill change.
Output: one-line lifecycle note in the report.
Quality signal: report states that a new session is needed.
Failure mode: debugging the repo when the session is simply stale.
Skill location: workflow step 6
Keep / merge / discard: Keep.

## Mechanism Card
Name: Lazy nested discovery
Source evidence: Read from source, section 7 "Nested skills are found lazily".
Trigger: A monorepo keeps skills under packages/<x>/.claude/skills/.
User job: Get nested skills surfaced.
Decision rule: With no root-level skills, nothing is announced at start. After the agent reads a file under packages/foo/ with the built-in read tool, the nested skill is surfaced for the rest of the session. Reading the same file through bash (cat) does not trigger it.
Procedure: classify nested skills as "lazy"; tell the agent to open a file under that subtree with the read tool.
Output: lazy-nested entries in the audit.
Quality signal: nested skills are labeled lazy, not announced.
Failure mode: expecting nested skills in the start-of-session list.
Skill location: workflow step 5; references/scanner-rules.md
Keep / merge / discard: Keep.

## Mechanism Card
Name: Read-then-follow routing
Source evidence: Read from source, sections 1, 5, 6.
Trigger: A request matches a skill description.
User job: Have the agent use the repo's process instead of inventing one.
Decision rule: The agent sees name, description and path of each announced skill; on a match it opens SKILL.md with the read tool first, then follows it, including shipped scripts and reference files.
Procedure: write descriptions as triggers (what it does + when); test with a request that states the outcome and never names the skill; inspect the first read in the turn.
Output: retest request + list of read calls.
Quality signal: the first read in the turn is the skill's SKILL.md.
Failure mode: description too vague to match; agent invents its own process.
Skill location: workflow step 7; examples/retest-prompts.md
Keep / merge / discard: Keep.

## Mechanism Card
Name: Repo skills vs Skills API
Source evidence: Read from source, section 8.
Trigger: Someone asks where a skill should live.
User job: Choose a distribution channel.
Decision rule: Repo: the skill belongs with the code and should change in the same pull request. API: org-wide, spans repositories, needs its own versioning, or must exist in sessions without a mounted repo. Same-name skills from both sources, or from two repositories, are both announced at distinct paths.
Procedure: apply the decision rule; report the choice.
Output: one-line recommendation.
Quality signal: choice cites which criterion applied.
Failure mode: uploading repo-coupled skills and letting them drift.
Skill location: workflow step 8
Keep / merge / discard: Keep.

## Mechanism Card
Name: Managed Agents mount configuration
Source evidence: Read from source, sections 1, 3, 4.
Trigger: Setting up the session that mounts the repository.
User job: Mount a repo on a hosted environment.
Decision rule: github_repository resource with plain https URL, authorization_token, checkout branch or commit, mount_path default /workspace/<repo-name>; anthropic_cloud environment only; beta header managed-agents-2026-04-01; agent carries no skills field.
Procedure: API calls in sections 3-5.
Output: a session with discovered skills.
Quality signal: agent lists the skills when asked.
Failure mode: self-hosted sandbox (no clone).
Skill location: none
Keep / merge / discard: Discard. Provider API surface; target is runtime-neutral. Recorded in the brief under "Mechanisms discarded".

## Mechanism Card
Name: Notebook scaffolding
Source evidence: Read from source, sections 1, 9.
Trigger: n/a
User job: n/a
Decision rule: pip install line, GITHUB_TOKEN check, stream helpers, archive/cleanup.
Procedure: n/a
Output: n/a
Quality signal: n/a
Failure mode: n/a
Skill location: none
Keep / merge / discard: Discard. Boilerplate; the `utilities` helpers are not in the source.

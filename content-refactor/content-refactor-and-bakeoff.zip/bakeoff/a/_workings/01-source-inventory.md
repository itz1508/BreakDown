# Source Inventory (content-to-skill step 2 + references/source-intake.md)

Route: PACKAGE_BUILD (a target path was given; PACKAGE_BUILD outranks SOURCE_AUDIT).
CHECKPOINT / STOP gates: none triggered (public page, local output path, no public push, no skill family).

Root: https://platform.claude.com/cookbook/managed-agents-cma-use-skills-from-a-repo
Source type: web page (rendered cookbook notebook: prose + code cells), fetched as markdown text.
Target runtime: runtime-neutral skill package (SKILL.md + references + scripts), English.
Read: full rendered page text, sections 1-9, all code cells as rendered.
Not read: the .ipynb on GitHub; the `utilities` module the notebook imports (`stream_until_end_turn`, `wait_for_idle_status`); the `cookbook-audit` skill files in anthropics/claude-cookbooks; linked Managed Agents docs; any executed cell output (the page shows none).
Unavailable: live behavior of the scanner (only described in prose); anthropic_cloud environment; beta access.

High-signal sections: 2 (layout), 4 (mount), 5-6 (discovery + read-then-follow), 7 (rules), 8 (repo vs Skills API).
Likely skill triggers: "structure .claude/skills", "why isn't my repo skill announced", "skill not picked up in session", "repo skills vs Skills API".
Recurring procedures: layout check; frontmatter check; count check; description-as-trigger check; lifecycle check.
Examples or cases: bare SKILL.md, doubly nested, missing .claude parent, packages/foo nested, same-name collision.
Rubrics or quality gates: none stated.
Uncertainty: see 03-source-to-skill-brief.md.

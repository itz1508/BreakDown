## Source-To-Skill Brief
Source boundary: rendered cookbook page text only (see 01-source-inventory.md). Notebook file, `utilities` module, and live scanner behavior not read.
Root job: let a person lay out and audit a repository's skill directory so a session-start scan announces every skill and the agent opens the right one on a matching request.
Target user: a developer keeping skills in a repository.
Mechanisms kept: layout contract; frontmatter tolerance and description limits; skill cap; scan lifecycle; lazy nested discovery; read-then-follow routing; repo vs Skills API.
Mechanisms discarded: Managed Agents mount configuration (github_repository resource, anthropic_cloud environment, beta header, checkout and mount_path settings, agent without a skills field); notebook scaffolding.
Skill shape: single procedural skill with references and one deterministic script.
Package plan: SKILL.md, references/scanner-rules.md, references/source-boundary.md, scripts/audit_skill_layout.py, agents/openai.yaml, examples/retest-prompts.md.
Validation plan: scripts/check_skill_package.py (pinned ce5776a) plus a run of the audit script on a fixture tree.
Open uncertainty:
- Which 64 directories are announced when more than 64 exist: the source does not say.
- How the announced catalog (name, description, path) is rendered in the prompt: not shown.
- What marks a truncated description: not stated.
- Whether matching a description to a request is deterministic: the source says the model routes on intent.

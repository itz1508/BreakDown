# Judgment calls where the content-to-skill protocol is silent
Each row is a place the pinned protocol did not determine the output, so the run chose.

| # | Decision point | Protocol text | Choice made | Effect |
|---|---|---|---|---|
| 1 | "Runtime-neutral" target | Step 2 lists targets: Codex skill folder, single SKILL.md, repository scaffold, patch plan. No neutral option. | Treated as "repository scaffold with portable files". | Fixes the target for discard decisions. |
| 2 | Provider-hosted mechanisms | No step classifies what a runtime provides. Anti-pattern "Tool fantasy" is the nearest rule. | Mount/env/beta header discarded and listed in the brief. Scanner rules kept, described as source-stated behavior. | No stand-in classification exists in the output. |
| 3 | Script or no script | "Add scripts only when repeated mechanical checks ... should be deterministic." | Layout classification is mechanical, so one script was added. | Gives a runnable artifact to test. |
| 4 | agents/openai.yaml | Required by the validator and the minimum-package list. | Created it, though the target is runtime-neutral. | Codex-specific file in a neutral package. |
| 5 | Constants in cards | Card template has no field for limits or constants. | Put 64 and 2,000 in "Decision rule". | Numbers survive only because they fit that field. |
| 6 | Open uncertainty content | Brief has an "Open uncertainty" field with no guidance on what qualifies. | Listed gaps noticed while reading. | Depends on the reader; not reproducible. |
| 7 | Claim ordering in the package | Boundaries: "Do not claim benchmark quality without validation or forward tests." Nothing covers claims about checks already run. | `references/source-boundary.md` line 15 ("Dry-run: ... checked only against a fixture tree") was written before any fixture check ran. The probe ran later and was valid 9 of 9, so the line is true now, but it was written unverified. | Shows a generated package can state a check that had not yet happened. |

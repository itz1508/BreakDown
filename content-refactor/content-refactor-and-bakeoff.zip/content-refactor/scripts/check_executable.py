#!/usr/bin/env python3
"""Executability probes for a generated skill package, kept separate from fidelity scoring.

compile      syntax-check every .py file and every python fenced block; list unresolved imports
identifiers  account for source identifiers: in package, only in the run records, or absent
materialize  write fixture trees from a fixtures file
probe        run an adapter against the fixture trees and compare with expected outcomes

None of these runs the source's own live sample. Live execution is reported as not_run by the caller.
"""

from __future__ import annotations

import argparse
import ast
import importlib.util
import json
import re
import sys
import tempfile
from pathlib import Path

TEXT = {".md", ".py", ".json", ".yaml", ".yml", ".txt", ".sh"}


def files(root: Path):
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.suffix in TEXT and "__pycache__" not in p.parts:
            yield p


def cmd_compile(a) -> int:
    pkg = Path(a.package)
    rows = []
    for p in files(pkg):
        text = p.read_text(encoding="utf-8", errors="replace")
        units = []
        if p.suffix == ".py":
            units.append((text, 1))
        if p.suffix == ".md":
            units += [(m.group(1), text[: m.start()].count("\n") + 2) for m in re.finditer(r"```python\n(.*?)```", text, re.S)]
        for src, line in units:
            row = {"file": p.relative_to(pkg).as_posix(), "line": line}
            try:
                tree = ast.parse(src)
            except SyntaxError as e:
                rows.append({**row, "status": "not_valid", "error": f"{e.msg} (line {e.lineno})", "unresolved_imports": []})
                continue
            mods = {n.name.split(".")[0] for x in ast.walk(tree) if isinstance(x, ast.Import) for n in x.names}
            mods |= {x.module.split(".")[0] for x in ast.walk(tree) if isinstance(x, ast.ImportFrom) and x.module and x.level == 0}
            miss = sorted(m for m in mods if m not in sys.stdlib_module_names and not (p.parent / f"{m}.py").exists() and importlib.util.find_spec(m) is None)
            rows.append({**row, "status": "valid", "unresolved_imports": miss})
    print(json.dumps({"package": str(pkg), "units": rows, "python_units": len(rows)}, indent=2))
    return 0


def cmd_identifiers(a) -> int:
    ids = json.loads(Path(a.signatures).read_text(encoding="utf-8"))["signatures"]
    pkg, rec = Path(a.package), (Path(a.records) if a.records else None)

    def where(root, ident):
        if not root:
            return []
        out = []
        for p in files(root):
            for n, line in enumerate(p.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
                if ident in line:
                    out.append(f"{p.relative_to(root).as_posix()}:{n}")
        return out[:3]

    rows = []
    for ident in ids:
        pk, rc = where(pkg, ident), where(rec, ident)
        rows.append({"identifier": ident, "bucket": "in_package" if pk else ("only_in_records" if rc else "absent"), "package_hits": pk, "record_hits": rc})
    print(json.dumps({"rows": rows}, indent=2))
    return 0


def expand(text: str, n: int | None = None) -> str:
    text = re.sub(r"\{\{REPEAT:(.*?):(\d+)\}\}", lambda m: m.group(1) * int(m.group(2)), text)
    return text.replace("{n:02d}", f"{n:02d}").replace("{n}", str(n)) if n is not None else text


def materialize_case(case: dict, root: Path) -> None:
    for rel, content in case.get("files", {}).items():
        t = root / rel
        t.parent.mkdir(parents=True, exist_ok=True)
        t.write_bytes(expand(content).encode("utf-8"))
    g = case.get("generate")
    if g:
        for n in range(g["count"]):
            t = root / expand(g["pattern"], n)
            t.parent.mkdir(parents=True, exist_ok=True)
            t.write_bytes(expand(g["content"], n).encode("utf-8"))


def cmd_materialize(a) -> int:
    fx = json.loads(Path(a.fixtures).read_text(encoding="utf-8"))
    for case in fx["cases"]:
        materialize_case(case, Path(a.outdir) / case["id"])
    print(f"materialized {len(fx['cases'])} cases under {a.outdir}")
    return 0


def cmd_probe(a) -> int:
    fx = json.loads(Path(a.fixtures).read_text(encoding="utf-8"))
    spec = importlib.util.spec_from_file_location("adapter", a.adapter)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    results = []
    for case in fx["cases"]:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            materialize_case(case, root)
            diffs = []
            try:
                got = mod.run(root)
            except Exception as e:  # adapter or script crashed
                results.append({"id": case["id"], "rule": case["source_rule"], "status": "failed", "diffs": [f"adapter/script error: {e}"]})
                continue
            exp = case["expected"]
            for path, st in exp.get("statuses", {}).items():
                if got.get("statuses", {}).get(path) != st:
                    diffs.append(f"{path}: expected {st}, got {got.get('statuses', {}).get(path)}")
            if "announced_count" in exp and got.get("announced_count") != exp["announced_count"]:
                diffs.append(f"announced_count: expected {exp['announced_count']}, got {got.get('announced_count')}")
            for path, det in exp.get("details", {}).items():
                for k, v in det.items():
                    gv = got.get("details", {}).get(path, {}).get(k)
                    if gv != v:
                        diffs.append(f"{path}.{k}: expected {v}, got {gv}")
            results.append({"id": case["id"], "rule": case["source_rule"], "status": "valid" if not diffs else "not_valid", "diffs": diffs})
    print(json.dumps({"fixtures": a.fixtures, "adapter": a.adapter, "results": results}, indent=2))
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("compile"); c.add_argument("package"); c.set_defaults(fn=cmd_compile)
    i = sub.add_parser("identifiers"); i.add_argument("package"); i.add_argument("--signatures", required=True); i.add_argument("--records"); i.set_defaults(fn=cmd_identifiers)
    m = sub.add_parser("materialize"); m.add_argument("fixtures"); m.add_argument("outdir"); m.set_defaults(fn=cmd_materialize)
    p = sub.add_parser("probe"); p.add_argument("fixtures"); p.add_argument("--adapter", required=True); p.set_defaults(fn=cmd_probe)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""First-pass fidelity scoring of a generated skill package against an expectations file.

Regex matching is a proxy. It reports where a pattern appears (file:line), not whether the
text means what the expectation requires. Every result needs a reviewed status from a person
or independent reviewer. This script never decides a verdict and always exits 0 on a normal run.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

def _package_files(run: Path) -> list[Path]:
    """Files under a skill package root only: a directory that holds a SKILL.md directly.
    Run records and measurement outputs sit outside any package root and must not be scored."""
    roots = [p.parent for p in run.glob("*/SKILL.md")] + ([run] if (run / "SKILL.md").exists() else [])
    exts = {".md", ".py", ".yaml", ".yml", ".json", ".txt"}
    return [f for r in roots for f in r.rglob("*") if f.is_file() and f.suffix in exts and "__pycache__" not in f.parts]


SCOPES = {
    "package": _package_files,
    "cards": lambda run: sorted(run.glob("_workings/02-*.md")),
    "workings": lambda run: sorted(run.glob("_workings/*.md")),
}
SCOPES["any"] = lambda run: SCOPES["package"](run) + SCOPES["workings"](run)


def find_hits(run: Path, scope: str, patterns: list[str]) -> list[dict]:
    rx = [re.compile(p, re.I) for p in patterns]
    hits = []
    for f in sorted(set(SCOPES[scope](run))):
        for n, line in enumerate(f.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if any(r.search(line) for r in rx):
                hits.append({"file": f.relative_to(run).as_posix(), "line": n, "text": line.strip()[:110]})
    return hits


def run_check(run: Path, check: dict) -> dict:
    scope = check.get("scope", "package")
    if "any" in check:
        hits = find_hits(run, scope, check["any"])
        return {"label": check["label"], "scope": scope, "matched": bool(hits), "hits": hits[:3]}
    if not SCOPES[scope](run):
        return {"label": check["label"], "scope": scope, "matched": False, "mode": "absent", "hits": [],
                "note": "scope has no files, so absence proves nothing"}
    hits = find_hits(run, scope, check.get("absent") or check.get("forbidden"))
    return {"label": check["label"], "scope": scope, "matched": not hits, "mode": "absent", "hits": hits[:3]}


def score(run: Path, spec: dict) -> dict:
    rows = []
    for e in spec["expectations"]:
        checks = [run_check(run, c) for c in e["checks"]]
        got = sum(c["matched"] for c in checks)
        if e.get("kind") == "prediction":
            status = "review_required"
        elif got == len(checks):
            status = "found"
        elif got:
            status = "partial"
        else:
            status = "missed"
        rows.append({"id": e["id"], "text": e["text"], "kind": e.get("kind", "expected"),
                     "inferred_by_user_list": e.get("not_in_source", False), "auto_status": status, "checks": checks})
    return {"source": spec["source"], "run_dir": str(run), "rows": rows, "not_run": spec.get("not_run", [])}


def render(result: dict) -> str:
    out = [f"# Auto score, source {result['source']}", "", "| id | auto_status | check results |", "|---|---|---|"]
    for r in result["rows"]:
        cells = "; ".join(f"{'Y' if c['matched'] else 'N'} {c['label']}" for c in r["checks"])
        out.append(f"| {r['id']} | {r['auto_status']} | {cells} |")
    out += ["", "## Evidence (first hits)"]
    for r in result["rows"]:
        out.append(f"\n### {r['id']} ({r['auto_status']}): {r['text']}")
        for c in r["checks"]:
            tag = "absent-ok" if c.get("mode") == "absent" and c["matched"] else ("matched" if c["matched"] else "no match")
            out.append(f"- [{tag}] {c['label']} (scope {c['scope']})")
            for h in c["hits"]:
                out.append(f"    - {h['file']}:{h['line']}: {h['text']}")
    out += ["", "## Not run"] + [f"- {x}" for x in result["not_run"]]
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--expectations", required=True)
    ap.add_argument("--run-dir", required=True, help="dir holding the generated package and _workings/")
    ap.add_argument("--json-out")
    args = ap.parse_args()
    run = Path(args.run_dir).resolve()
    if not run.is_dir():
        print(f"not a directory: {run}", file=sys.stderr)
        return 2
    result = score(run, json.loads(Path(args.expectations).read_text(encoding="utf-8")))
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(render(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Measurement Rubric

## Status vocabulary

| Where | Values |
|---|---|
| Fidelity of one expectation | `found`, `partial`, `missed` (reviewed); the regex proxy gives `auto_status` and `review_required` for predictions |
| Diagnostic evidence | `valid`, `not_valid`, `uncertainty` |
| Execution state | `completed`, `failed`, `blocked`, `not_run`, `skipped` |

A converter's own words (for example "passed") are quoted as `contract_label` with scope, evidence, impact, and next action.

## Fidelity: what each status means

- `found`: the package text states the expected mechanism with the expected specifics (numbers, named cases, boundaries), at a cited file:line.
- `partial`: some required parts are present or the idea is present without a required specific, such as a label without a classification.
- `missed`: no text in the package or records states it.
- Where a mechanism is meant to be dropped, `found` needs both: absent from the package, and recorded as dropped in the run records. A drop recorded only outside the package is noted, because a future agent cannot see it.
- Rows marked `not_in_source` test inference. Treat them as the most exposed to a generator that has seen the list.

## Executability: four probes

| Probe | Question | Can prove | Cannot prove |
|---|---|---|---|
| E1 compile | Does every python unit parse? Which imports are unresolved? | syntax, dependency closure | behavior |
| E2 behavior | Does the generated script agree with fixtures built from the source's stated rules? | agreement with the written rules | agreement with the real system, when the script is itself a stand-in; protection against a misreading shared by script author and fixture author |
| E3 identifiers | Which of the source's own identifiers survive in the package, only in records, or nowhere? | what the conversion kept and what it dropped without a record | whether dropped items mattered |
| E4 live | Does the source's own sample run? | the sample's real behavior | n/a; usually `not_run` for lack of credentials |

## Predictions

Written before the run, recorded as `kind: prediction`. The scorer returns evidence lines only. The reviewer decides `supported`, `partial`, or `not supported`, and says how contamination could have changed the result.

## Contamination handling

If the generator saw the expectations, label the run `not_independent` and the independence status `uncertainty`. Results that contamination could only have inflated (`found`) are weak evidence; results it could not have helped (`missed`, `partial`) are the stronger signal.

## Instrument rules

- Run a negative control on every instrument before trusting its good results (see `references/instrument-selftest.md`).
- A scope that scans files must never contain the instrument's own output.
- An absence check needs a non-empty scope.
- A changed status on an unchanged package is a defect in the instrument until explained.

# Instrument self-test (run 2026-11-19)

Purpose: show that each instrument can report a bad result before its good results are trusted.

| Instrument | Control | Result | Action |
|---|---|---|---|
| `check_executable.py probe` | adapter that announces every SKILL.md | 8 of 9 fixtures reported `not_valid`; F1 (root skill) correctly stayed `valid` | none |
| `score_bakeoff.py` | package directory with no files | expectations that need a positive match reported `missed`; the three "dropped" expectations reported `partial` because the absence check passed vacuously | fixed: an absence check now reports no match when its scope has no files; re-run gave `missed` for those rows |
| `score_bakeoff.py` | regex proxy on real packages | `A3.model_dependent_matching` matched the word "deterministic" on unrelated lines (script description) | not fixed: the proxy cannot read meaning; every row needs a reviewed status |

Not tested: a control where a package contains the right words with the wrong meaning. The scorer cannot catch that; only review can.

## Defect found after the first table (same day)

| Instrument | Symptom | Cause | Action |
|---|---|---|---|
| `score_bakeoff.py` | A re-run after saving measurement outputs flipped three rows (`A2.scanner_standin`, `A2.injection_standin`, `A3.missing_file_read`) and degraded the three "dropped" rows | the "package" scope was every file outside `_workings/`, so the scorer's own saved output (which holds the regex patterns) was scored as package content | fixed: package scope is now only directories that hold a `SKILL.md` directly; re-run reproduced the first, unpolluted statuses exactly |

Rule that follows: never save measurement output inside a scanned scope, and treat any status change between two runs on an unchanged package as an instrument defect until explained.

# Bake-off Protocol

## Inputs

| Item | Value used in the reference run |
|---|---|
| Converter | gnipbao/content-to-skill at `ce5776a5161065836ed4647f9b96629d062ffdee` |
| Source A | https://platform.claude.com/cookbook/managed-agents-cma-use-skills-from-a-repo |
| Source B | https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-search-tool |
| Target | runtime-neutral, English |
| Outputs | `bakeoff/a/`, `bakeoff/b/` |

## Run layout

```txt
bakeoff/<a|b>/
├── <generated-skill>/        package only; nothing else lives here
├── _workings/
│   ├── 01-source-inventory.md
│   ├── 02-mechanism-cards.md
│   ├── 03-source-to-skill-brief.md
│   └── 04-judgment-calls.md  every place the converter did not decide the output
└── measurements/             scorer and probe output; never inside a scanned scope
```

## Steps

1. Clone the converter and check out the pinned commit. Confirm with `git rev-parse HEAD`. Read SKILL.md, `references/*`, and the validator before running anything.
2. Generate A and B with a fresh-context agent (prompt below).
3. Run the converter's validator on each package. Report it as `contract_label`.
4. `python scripts/score_bakeoff.py --expectations references/expectations-a.json --run-dir bakeoff/a --json-out bakeoff/a/measurements/auto-score-a.json`
5. Read every cited line. Record reviewed statuses.
6. `python scripts/check_executable.py compile <package>`; `identifiers <package> --signatures references/expectations-a.json --records bakeoff/a/_workings`; for a package with a script, write an adapter and run `probe references/fixtures-a.json --adapter <adapter>`.
7. Stop after the report.

## Independence rule

The generator must not have read the expectations, the predictions, or earlier results. Give it only the prompt below. If the person who wrote the expectations is also the operator, the operator must not paste them into the generator's context.

## Fresh-context generator prompt

```md
Run the converter pinned at <commit> on this source: <URL>.
Before running anything, read its SKILL.md, references/*, and its validator script.
Target: runtime-neutral, English. Write the package to <output>/<generated-skill>/ and
your records to <output>/_workings/ as 01-source-inventory.md, 02-mechanism-cards.md,
03-source-to-skill-brief.md, and 04-judgment-calls.md. In 04, list every place the converter's
protocol did not determine your choice, and what you chose.
Run the converter's validator and report its exact output. Report anything you did not run.
Do not look for or read any expectations, scores, or results files.
```

## Adapter contract for the behavioral probe

A generated script has its own command line and output, so the tester writes a small adapter (`run(root: Path) -> dict`) that returns:

```json
{"statuses": {"<path>": "announced|ignored|lazy_nested"}, "announced_count": 0, "details": {"<path>": {"name": "", "description_empty": false, "truncated": false}}}
```

Keep the adapter in `measurements/`, not in the package.

## Stop condition

The report is written and the not-run list is complete. Anything that adds capability, such as a supplement, a new converter step, or a repair of the generated package, waits for the person's decision.
